<?php
\Magento\Framework\Component\ComponentRegistrar::register(
    	\Magento\Framework\Component\ComponentRegistrar::MODULE,
    	'Rbj_Checkout',
    	__DIR__
);