var config = {
    map: {
        '*': {
            "Magento_Checkout/js/action/place-order" : 'Rbj_Checkout/js/action/place-order',
            "Magento_Checkout/js/view/payment/default" : "Rbj_Checkout/js/view/payment/default"
        }
    }
};