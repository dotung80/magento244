
require(
    [
        'jquery',
        'Magento_Ui/js/modal/modal' 

    ],
    function ($) {


        // form old =================================================================
        $('#submit').on('click', function (e) {
            $orderId = $('#input').val();
            console.log("$(this).val()", $(this).text());

            // call function
            // submit($orderId);
            connectionNats($orderId)
        });


        async function connectionNats($orderId) {


            // to create a connection to a nats-server:
            // const nc = await connect({ servers: "wss://magento217.local:4333" });
            // console.log('nc',nc);
            // const sub = nc.subscribe("hello");
            // (async () => {
            //   for await (const m of sub) {
            //     console.log(`[${sub.getProcessed()}]`);
            //   }
            //   console.log("subscription closed");
            // })();
            let webSocket = new WebSocket('wss://magento217.local:4333');
            webSocket.onmessage = function (e) { console.log(e) }
            webSocket.send("test")
        }

    }
);
