var config = {
    map: {
        '*': { 
            // connect: 'Custom_NatsClientNodejs/node_modules/nats/lib/src/connect',
            // StringCodec:
            // nats: 'Custom_NatsClientNodejs/node_modules/nats'
        }
    },
    paths: {
        // nats: './node_modules/nats',
        // connect: './node_modules/nats/lib/src/connect'
    }
};