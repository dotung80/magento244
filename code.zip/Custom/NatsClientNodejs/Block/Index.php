<?php

namespace Custom\NatsClientNodejs\Block;

class Index extends \Magento\Framework\View\Element\Template
{
	public function __construct(\Magento\Framework\View\Element\Template\Context $context)
	{
		parent::__construct($context);
	}

	public function sayHello($msg = 'message block')
	{
		return __($msg);
	}

	public function Sub($subject){
        $connectionOptions = new \Nats\ConnectionOptions();
        $connectionOptions->setHost('magento217.local');
        $client = new \Nats\Connection($connectionOptions);
        $client->connect();

        // Simple Subscriber.
        $client->subscribe(
            $subject,
            function ($message) {
                printf("Data: %s\r\n", $message->getBody());
            }
        );

        $client->close();
    }
 
}
