var config = {
    map: {
        '*': {
            jsFuncIndex: 'Custom_Nats/js/jsFuncIndex',
            index:'Custom_Nats/js/index',
        }
    }
};