define([
    "jquery"
], function ($) {
    "use strict";
    return function jsFuncIndex (msg) {
        alert(msg);
        console.log("heello over log");
    }
}
)