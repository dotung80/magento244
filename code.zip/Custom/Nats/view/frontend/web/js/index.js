
require(
    [
        'jquery',
        'Magento_Ui/js/modal/modal'
        
    ],
    function ($, modal, hello) {
 

        var options = {
            type: 'popup',
            responsive: true,
            innerScroll: true,
            title: 'Popup Title',
            buttons: [{
                text: $.mage.__('Close'),
                class: '',
                click: function () {
                    this.closeModal();
                }
            }]
        };
        var pupop = $("#popup-modal-main").modal(options)
 
        $("#click-here").on('click', function (e) {

            // disable 
            // e.defaultPrevented = true;

            // show conect when processing payment
            var contentPopup = `<div class="loader"></div>`;
            var quoteId = $("#order_id").val();
            var mess = "processing order id " + quoteId;

            contentPopup = contentPopup + mess; 
            // open popup
            pupop.modal("openModal");

            // Processing
            $("#contentPopup").html(contentPopup); 
            var url = "/nats-test/submit/index";
 
            subscribe(url, quoteId);

        });
 
        async function subscribe(url, quoteId) {
            $.ajax({
                type: "GET",
                url: url,
                data: {
                    quoteId: quoteId
                },
                async: true,
                /* If set to non-async, browser shows page as "Loading.."*/
                cache: false,
                timeout: 60000,
                /* Timeout in ms */

                success: function (data) {
                    pupop.modal("closeModal");
                    // console.log();
                    alert('PaymentStatus successfully');
                    $('#popup-modal-main').on('modalclosed', function () {
                        /*insert code here*/
                        console.log('data ',data);
                    });
                },
                statusCode: {
                    404: function () {
                        pupop.modal("closeModal");
                        alert("page not found (404)");
                        return ;
                    },
                    403: function () {
                        pupop.modal("closeModal");
                        alert("page not found (403)");
                        return ;

                    },
                    500: function () {
                        pupop.modal("closeModal");
                        alert("page not found (500)");
                        return ;

                    },
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    pupop.modal("closeModal");
                    alert("error " + "(" + errorThrown + ")");
                    return ;

                }
            });

            // open popup
            pupop.modal("closeModal");
        }

    }
);
