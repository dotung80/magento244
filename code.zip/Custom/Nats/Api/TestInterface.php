<?php 
namespace Custom\Nats\Api;
 
 
interface TestInterface { 

 
     /**
      * form submit method GET
      * @return mixed return json
      *
      */
     public function testGet();


      
     /**
      * form submit method POST
      * @return mixed return json
      *
      */
      public function testPost();

 

    
}