<?php 
namespace Custom\Nats\Api;
 
 
interface PaymentStatusInterface { 

 
     /**
      * form submit method GET
      * @param string $status status or order
      * @param mixed $quoteId orderId of order
      * @return mixed return json 
      *
      */
     public function paymentStatus($quoteId, $status);


     /**
      * form submit method GET 
      * @return mixed return json
      *
      */
      public function testUpdateOderNew();

 
    
}