<?php

namespace Custom\Nats\Model;


class PaymentStatusManager
{
    protected $orderFactory;

    protected $_orderCollectionFactory;

	protected $quoteFactory;

    
	protected $HOST_URL = "magento217.local";

    /**
     * constructor
     *
     * @param \Magento\Framework\Webapi\Rest\Request $request
     */

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Quote\Model\QuoteFactory $quoteFactory
    ) {
        $this->_orderCollectionFactory = $orderCollectionFactory;
        $this->orderFactory = $orderFactory;
        // parent::__construct($context);

		$this->quoteFactory = $quoteFactory;
    }

    public function paymentStatus($quoteId, $status)
    {
        try {

            $quote = $this->quoteFactory->create()->load($quoteId);

            if ($quote) {
                // configure connection NATS SERVER
                $connectionOptions = new \Nats\ConnectionOptions();
                $connectionOptions->setHost($this->HOST_URL);
                $client = new \Nats\Connection($connectionOptions);
                $client->connect();

                // Simple publish.
                $client->publish($quoteId, '$data');
                $client->close();


                return json_encode(['status' => 'true', 'message' => 'paymented successfully', 'data' => $quote]);
            } else {
                return json_encode(['status' => 'false', 'message' => 'Id not found quote', 'data' => []]);
            }
        } catch (\Throwable $th) {
            //throw $th;
            echo $th;
            return json_encode(['json_data' => 'ERRO result from Model', 'message' => $th]);
        }
    }




    public function testUpdateOderNew()
    {
        try {

            for ($i = 5; $i <= 18; $i++) {
                $order = $this->orderFactory->create()->load($i);
                if ($order) {
                    $order->setState('new');
                    $order->setStatus('processing');
                    $order->save();
                } else {
                    continue;
                }
            }
            return json_encode(['status' => 'true', 'message' => 'completed', 'data' => []]);
        } catch (\Throwable $th) {
            //throw $th;
            echo $th;
            return json_encode(['json_data' => 'ERRO result from Model', 'message' => $th]);
        }
    }
}
