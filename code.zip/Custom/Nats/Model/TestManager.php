<?php

namespace Custom\Nats\Model;



class TestManager
{
    public function testGet()
    {

        $client = new \Nats\Connection();
        $client->connect();

        // Simple Publisher.
        $client->publish('foo', 'Marty McFly');

        // Wait for 1 message.
        $client->wait(1);

        return "['a'=>'b', 'c'=>'d', 'e'=>'f', 'g'=>'h]";
    }

    public function testPost()
    {

        return "['a'=>'b', 'c'=>'d', 'e'=>'f', 'g'=>'h]";
    }
}
