<?php

namespace Custom\Nats\Controller\Submit;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class TestOrder extends Action
{


	protected $resultJsonFactory;

	protected $HOST_URL = "magento217.local";

	protected $orderFactory;


	/**
	 * @param Context $context
	 * @param PageFactory $resultPageFactory
	 */
	public function __construct( 
		PageFactory $resultPageFactory,
		\Magento\Sales\Model\OrderFactory $orderFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
	) {
		$this->_resultPageFactory = $resultPageFactory; 
		$this->resultJsonFactory = $resultJsonFactory;
		$this->orderFactory = $orderFactory;
	}


	/**
	 * help result of controller is JSON type
	 *
	 * @param \Magento\Framework\Webapi\Exception $httpCode
	 * @param array $data
	 * @return void
	 */
	private function _getResultJson(int $httpCode = 400, $data = [])
	{
		$resultJson = $this->resultJsonFactory->create();
		return $resultJson->setHttpResponseCode($httpCode)
			->setData($data);
	}

	public function execute()
	{
		$orderId = $this->getRequest()->getParam('orderId');
		$data = [];

		if (!$orderId) {
			$data = ['message' => '400 Bad Request: Máy chủ không thể hiểu yêu cầu do cú pháp không hợp lệ.', 'data' => (array)$orderId];
			return $this->_getResultJson(400, $data);
		}

		$order = $this->orderFactory->create()->load($orderId);
		if (!$order->getQuoteId()) {
			$data = ['message' => '400 Bad Request: Máy chủ không thể hiểu yêu cầu do cú pháp không hợp lệ.', 'data' => (array)$order->getQuoteId()];
			return $this->_getResultJson(400, $data);
		}
		if (
			$order->getState() === $order::STATE_NEW
			&& $order->getStatus()  === \Custom\PaymentStatus\Model\OrderUpdate::ORDER_STATUS_PENDING
		) {
			$data = ['message' => '400 Bad Request: Máy chủ không thể hiểu yêu cầu do cú pháp không hợp lệ.', 'data' => (array)$order->getState() === $order::STATE_NEW];
			return $this->_getResultJson(400, $data);
		}
	}
}
