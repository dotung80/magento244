<?php

namespace Custom\Nats\Controller\Submit;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Index extends Action
{


	protected $resultJsonFactory;

	protected $HOST_URL = "magento217.local";

	protected $orderFactory;

	protected $quoteFactory;

	protected $messageManager;


	/**
	 * @param Context $context
	 * @param PageFactory $resultPageFactory
	 */
	public function __construct(
		Context $context,
		
		PageFactory $resultPageFactory,
		\Magento\Sales\Model\OrderFactory $orderFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory, 
		  \Magento\Quote\Model\QuoteFactory $quoteFactory,
		  \Magento\Framework\Message\ManagerInterface $messageManager
	) {
		$this->_resultPageFactory = $resultPageFactory;
		$this->resultJsonFactory = $resultJsonFactory;
		$this->orderFactory = $orderFactory; 
		$this->quoteFactory = $quoteFactory;
		$this->messageManager = $messageManager;
		parent::__construct($context);
	}


	/**
	 * help result of controller is JSON type
	 *
	 * @param \Magento\Framework\Webapi\Exception $httpCode
	 * @param array $data
	 * @return void
	 */
	private function _getResultJson(int $httpCode = 400, $data = [])
	{
		$resultJson = $this->resultJsonFactory->create();
		return $resultJson->setHttpResponseCode($httpCode)
			->setData($data);
	}

	public function execute()
	{	
		$quoteId = $this->getRequest()->getParam('quoteId');
		$data = [];

		// configure connection NATS SERVER
		$connectionOptions = new \Nats\ConnectionOptions();
		$connectionOptions->setHost($this->HOST_URL);
		$client = new \Nats\Connection($connectionOptions);
		$client->connect();

		if (!$quoteId) {
			return $this->_getResultJson(403);
		}

		try {

			$quote = $this->quoteFactory->create()->load($quoteId);
			if ($quote) {
				

				// Simple Subscriber.
				$client->subscribe(
					$quoteId,
					function ($message) {
						printf("Data: %s\r\n", $message->getBody());
						$data = ['status' => 'true', 'message' => 'PaymentStatus successfully', 'data' => $message->getBody()];
						return $this->_getResultJson(200, $data);
					}
				);
 
				// Wait for 1 message.
				$client->wait(1);
				$client->close();

				// message push frontend
				$this->messageManager->addSuccessMessage('Payment successfully');



				return;
			} else {
				$data = ['status' => 'false', 'message' => 'Not found quote id'];
				return $this->_getResultJson(404, $data);
			}
		} catch (\Throwable $th) {
			$client->close();
			throw $th;
			return $this->_getResultJson(500, ["tuankhoi" => $th]);
		}
		// return $this->_getResultJson(403);
	}

	// with quoteId of quote cart
	private function updateOrderStatus($quoteId){
		try {
			//code...
		} catch (\Throwable $th) {
			//throw $th;
		}
	}
}
