<?php

namespace Custom\Nats\Controller\NatsClient;

class Sub
{
    public function __construct(){}

    public function Sub($subject){
        $connectionOptions = new \Nats\ConnectionOptions();
        $connectionOptions->setHost('magento217.local');
        $client = new \Nats\Connection($connectionOptions);
        $client->connect();

        // Simple Subscriber.
        $client->subscribe(
            $subject,
            function ($message) {
                printf("Data: %s\r\n", $message->getBody());
            }
        );

        $client->close();
    }
}
