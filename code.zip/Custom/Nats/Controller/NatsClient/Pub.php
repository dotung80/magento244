<?php

namespace Custom\Nats\Controller\NatsClient;

class Pub
{
    public function __construct()
    {
    }

    public function Pub($subject,$data)
    {
        $connectionOptions = new \Nats\ConnectionOptions();
        $connectionOptions->setHost('magento217.local');
        $client = new \Nats\Connection($connectionOptions);
        $client->connect();

        // Simple Publisher.
        $client->publish($subject, $data);
        $client->close();
    }
}
