<?php

namespace Custom\Nats\Block;

class Index extends \Magento\Framework\View\Element\Template
{
	public function __construct(\Magento\Framework\View\Element\Template\Context $context)
	{
		parent::__construct($context);
	}

	public function sayHello($msg = 'message block')
	{
		return __($msg);
	}

	// public function getButtonHtml()
	// {
	// 	$button = $this->getLayout()->createBlock(
	// 		'Magento\Backend\Block\Widget\Button'
	// 	)->setData(
	// 		[
	// 			'id' => 'clear_button',
	// 			'label' => __('Clear'),
	// 			'on_click' => sprintf("location.href = '%s';", $this->getAjaxUrl()),
	// 		]
	// 	);

	// 	return $button->toHtml();
	// }

	// public function getAjaxUrl()
	// {
	// 	return $this->getUrl('vendor_module/system_config/ClearCtrl');
	// }
}
