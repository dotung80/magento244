<?php 
namespace Custom\Api\Model;
 
 
class PostManagement {

	/**
	 * {@inheritdoc}
	 */
	public function getPost($param)
	{
		// return 'api GET return the $param ' . $param;
		try{
            $response = [
                'name' => '123',
                'age' => '25',
                'job' => 'developer'
            ];
        } catch (\Exception $e) {
            $response=['error' => $e->getMessage()];
        }
        return json_encode($response);
	}
}