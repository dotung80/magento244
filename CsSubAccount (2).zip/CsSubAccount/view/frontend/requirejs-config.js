/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    map: {
        '*': {
            cedrolesTree: 'Ced_CsSubAccount/js/roles-tree',
            cedjstree: 'Ced_CsSubAccount/js/jstree',
            cedjqueryhotkeys: 'Ced_CsSubAccount/js/jqueryhotkeys'
        }
    }
};
