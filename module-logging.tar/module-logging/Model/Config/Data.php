<?php
/**
 * Logging configuration data container. Provides fieldset configuration data.
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Logging\Model\Config;

class Data extends \Magento\Framework\Config\Data
{
}
